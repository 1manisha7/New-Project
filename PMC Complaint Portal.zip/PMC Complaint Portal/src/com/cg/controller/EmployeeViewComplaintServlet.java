package com.cg.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dao.ComplaintDAO;
import com.cg.dao.IComplaintDAO;
import com.cg.entity.Complaint;

@WebServlet("/EmployeeViewComplaintServlet")
public class EmployeeViewComplaintServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String area = request.getParameter("area");	
		IComplaintDAO iComplaintDAO = new ComplaintDAO();
		List<Complaint> complaints = iComplaintDAO.viewAreawiseComplaint(area);
		request.setAttribute("areaWiseComplaints", complaints);
		request.getRequestDispatcher("PMCEmployeeHomePage.jsp").forward(request, response);
	}
}
