package com.cg.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dao.ComplaintDAO;
import com.cg.dao.IComplaintDAO;
import com.cg.entity.Complaint;
import com.cg.entity.UserRole;

@WebServlet("/RegisterComplaintServlet")
public class RegisterComplaintServlet extends HttpServlet 
{

	private static final long serialVersionUID = 1L;
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		HttpSession session = request.getSession();
		String complaintDetails = request.getParameter("complaintDetails");
		UserRole userRole = (UserRole) session.getAttribute("user");
		
		Complaint complaint = new Complaint(userRole.getUserId(), complaintDetails, userRole.getArea());
		
		IComplaintDAO complaintDAO = new ComplaintDAO();
		complaintDAO.registerComplaint(complaint);
		
		response.getWriter().println("<script>alert('Complaint registered successfully')</script>");
		request.getRequestDispatcher("CitizenHomePage.jsp").include(request, response);
	}
}
