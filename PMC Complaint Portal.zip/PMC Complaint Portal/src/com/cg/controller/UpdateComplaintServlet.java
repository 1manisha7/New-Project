package com.cg.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dao.ComplaintDAO;
import com.cg.dao.IComplaintDAO;
import com.cg.entity.Complaint;
import com.cg.entity.Worker;

@WebServlet("/UpdateComplaintServlet")
public class UpdateComplaintServlet extends HttpServlet 
{
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		int complaintId = Integer.parseInt(request.getParameter("complaintId"));
		String complaintDetails = request.getParameter("complaintDetails");
		String complaintStatus = request.getParameter("complaintStatus");
		String area = request.getParameter("area");
		String workerId = request.getParameter("workerId");
		
		Complaint complaint = new Complaint();
		complaint.setComplaintId(complaintId);
		
		complaint.setComplaintStatus(complaintStatus);
		
		complaint.setWorkerId(workerId);
		
		IComplaintDAO complaintDAO = new ComplaintDAO();
		complaintDAO.updateComplaint(complaint);
		
		response.getWriter().println("<script>alert('Complaint updated successfully')</script>");
		request.getRequestDispatcher("PMCEmployeeHomePage.jsp").include(request, response);
		
	}
}
