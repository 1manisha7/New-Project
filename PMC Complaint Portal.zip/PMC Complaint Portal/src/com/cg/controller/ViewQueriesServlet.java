package com.cg.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dao.IQueriesDAO;
import com.cg.dao.QueriesDAO;
import com.cg.entity.Queries;

@WebServlet("/ViewQueriesServlet")
public class ViewQueriesServlet extends HttpServlet{
@Override
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	// TODO Auto-generated method stub
	IQueriesDAO iQueriesDAO=new QueriesDAO();
	List<Queries> queries=iQueriesDAO.viewAllQueries();
	System.out.println(queries);
	request.setAttribute("viewAllQueries",queries );
	request.getRequestDispatcher("ViewQueries.jsp").forward(request, response);
}
}
