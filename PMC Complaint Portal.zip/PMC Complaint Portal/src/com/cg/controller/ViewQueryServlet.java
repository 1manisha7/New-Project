package com.cg.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dao.IQueriesDAO;
import com.cg.dao.QueriesDAO;
import com.cg.entity.Queries;
@WebServlet("/ViewQueryServlet")
public class ViewQueryServlet extends HttpServlet{
@Override
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	// TODO Auto-generated method stub
	int messageId=Integer.parseInt(request.getParameter("messageId"));
	IQueriesDAO iQueriesDAO=new QueriesDAO();
	Queries query=iQueriesDAO.viewQuery(messageId);
	request.setAttribute("query", query);
	request.getRequestDispatcher("ViewQuery.jsp").forward(request, response);
}
}
