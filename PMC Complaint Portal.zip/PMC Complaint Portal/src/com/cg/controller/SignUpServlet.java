package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dao.ISignUpDAO;
import com.cg.dao.SignUpDAO;
import com.cg.entity.UserRole;

@WebServlet("/SignUpServlet")
public class SignUpServlet extends HttpServlet
{

	private static final long serialVersionUID = 1L;

@Override
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	// TODO Auto-generated method stub
	
	String userId=request.getParameter("userId");
	String userName=request.getParameter("userName");
	String password=request.getParameter("password");
	
	String role=request.getParameter("role");
	String area=request.getParameter("area");
	
	UserRole userRole=new UserRole(userId,userName,password,role,area);
	ISignUpDAO iSignUp=new SignUpDAO();
	iSignUp.addUser(userRole);
	
	request.setAttribute("successfulRegister", "You have successfully signed up");
	request.getRequestDispatcher("Login.jsp").forward(request, response);
}
}