package com.cg.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class UserRole 
{
	@Id
	private String userId;
	private String userName;
	private String password;
	private String userRole;
	private String area;
	
	
	
	public UserRole() {
		super();
	}
	public UserRole(String userName, String password, String userRole, String area) {
		super();
		this.userName = userName;
		this.password = password;
		this.userRole = userRole;
		this.area = area;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public UserRole(String userId, String userName, String password, String userRole, String area) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.password = password;
		this.userRole = userRole;
		this.area = area;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUserRole() {
		return userRole;
	}
	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	
	
}
