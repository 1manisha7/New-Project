package com.cg.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Queries {

	private String name;
	private String email;
	private String message;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int messageId;
	private String subject;
	private String status;
	
	public Queries() {
		super();
	}
	public Queries(String name, String email, String message, int messageId, String subject, String status) {
		super();
		this.name = name;
		this.email = email;
		this.message = message;
		this.messageId = messageId;
		this.subject = subject;
		this.status = status;
	}
	public Queries(String name, String email, String message, String subject, String status) {
		super();
		this.name = name;
		this.email = email;
		this.message = message;
		this.subject = subject;
		this.status = status;
	}
	public Queries(String name, String email, String message, String subject) {
		super();
		this.name = name;
		this.email = email;
		this.message = message;
		this.subject = subject;
		this.status="unread";
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public int getMessageId() {
		return messageId;
	}
	public void setMessageId(int messageId) {
		this.messageId = messageId;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "Queries [name=" + name + ", email=" + email + ", message=" + message + ", messageId=" + messageId
				+ ", subject=" + subject + ", status=" + status + "]";
	}
	
	
}
