package com.cg.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Worker 
{
	@Id
	private String workerId;
	private String workerName;
	private String workerArea;
	
	
	
	public Worker() {
		super();
	}
	public Worker(String workerName, String workerArea) {
		super();
		this.workerName = workerName;
		this.workerArea = workerArea;
	}
	public Worker(String workerId, String workerName, String workerArea) {
		super();
		this.workerId = workerId;
		this.workerName = workerName;
		this.workerArea = workerArea;
	}
	public String getWorkerId() {
		return workerId;
	}
	public void setWorkerId(String workerId) {
		this.workerId = workerId;
	}
	public String getWorkerName() {
		return workerName;
	}
	public void setWorkerName(String workerName) {
		this.workerName = workerName;
	}
	public String getWorkerArea() {
		return workerArea;
	}
	public void setWorkerArea(String workerArea) {
		this.workerArea = workerArea;
	}
	
	
	
}
