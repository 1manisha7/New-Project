package com.cg.dao;

import java.util.List;

import com.cg.entity.Complaint;

public interface IComplaintDAO 
{
	public void registerComplaint(Complaint complaint);
	public List<Complaint> viewAreawiseComplaint(String area);
	public List<Complaint> viewCitizenWiseComplaint(String userId);
	public Complaint viewComplaint(int complaintId);
	void updateComplaint(Complaint complaint);
	void giveFeedbackRating(Complaint complaint);
}
