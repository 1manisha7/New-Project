package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;

import com.cg.entity.Queries;
import com.cg.utility.JPAUtility;


public class QueriesDAO implements IQueriesDAO{

	static EntityManagerFactory factory = JPAUtility.getFactory();
	@Override
	public void addQuery(Queries query) {
		// TODO Auto-generated method stub
		EntityManager manager=factory.createEntityManager();
		EntityTransaction transaction=manager.getTransaction();
		transaction.begin();
		try
		{
			manager.persist(query);
			transaction.commit();
		}
		catch(PersistenceException e)
		{
			e.printStackTrace();
		}
		finally {
			manager.close();
		}
	}
	@Override
	public List<Queries> viewAllQueries() {
		// TODO Auto-generated method stub
		EntityManager manager=factory.createEntityManager();
		EntityTransaction transaction=manager.getTransaction();
		transaction.begin();
		TypedQuery<Queries> queries=null;
		try
		{
			 queries=manager.createQuery("select q from Queries q", Queries.class);
		}
		catch(PersistenceException e) {
			e.printStackTrace();
		}
	List<Queries> list=queries.getResultList();
       return list;
}
	@Override
	public Queries viewQuery(int messageId) {
		// TODO Auto-generated method stub
		EntityManager manager=factory.createEntityManager();
		EntityTransaction transaction=manager.getTransaction();
		transaction.begin();
		Queries query=null;
		try
		{
			query=manager.find(Queries.class, messageId);
			query.setStatus("read");
			manager.persist(query);
			transaction.commit();
		}
		catch(PersistenceException e) {
			e.printStackTrace();
		}
		return query;
	}
}