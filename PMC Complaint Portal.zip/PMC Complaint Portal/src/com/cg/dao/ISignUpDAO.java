package com.cg.dao;

import com.cg.entity.UserRole;

public interface ISignUpDAO 
{

	public void addUser(UserRole userole);
	
}
