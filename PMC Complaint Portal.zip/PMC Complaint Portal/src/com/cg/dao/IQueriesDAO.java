package com.cg.dao;

import java.util.List;

import com.cg.entity.Queries;

public interface IQueriesDAO {
void addQuery(Queries query);
List<Queries> viewAllQueries();
Queries viewQuery(int messageId);
}
