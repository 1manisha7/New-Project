package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.TypedQuery;

import com.cg.entity.Worker;
import com.cg.utility.JPAUtility;

public class WorkerDAO implements IWorkerDAO 
{
	static EntityManagerFactory factory = JPAUtility.getFactory();
	@Override
	public List<Worker> viewAreawiseWorker(String area) 
	{
		EntityManager manager = factory.createEntityManager();
		List<Worker> workersList;
		TypedQuery<Worker> workers= manager.createQuery("select w from Worker w where w.workerArea='"+area+"'", Worker.class);
		workersList = workers.getResultList();
		return workersList;
	}
	
}
